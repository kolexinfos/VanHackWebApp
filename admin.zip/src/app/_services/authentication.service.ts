import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http'
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

import { AppConfig } from '../app.config'

@Injectable()
export class AuthenticationService {
    constructor(private http: Http, private config: AppConfig){

    }

    login(username:string, password:string){
        return this.http.post(this.config.apiUrl, {username:username, password:password})
        .map((response: Response) => {
            //Login successful if there is a JWT token in the response
            let user = response.json();
            if(user && user.token){
                //store the user details and jwt in locat storage to keep user logged in
                localStorage.setItem('currentUser', JSON.stringify(user));
            }
        })
    }

    logout(){
        //remove the user from the localstorage to log user out
        localStorage.removeItem('currentUser');
    }
}