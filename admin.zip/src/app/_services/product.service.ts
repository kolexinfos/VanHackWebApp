import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http'
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

import { AppConfig } from '../app.config'
import { ProductModel} from '../_models/ProductModel'

@Injectable()
export class ProductService {

    constructor(public http: Http, private config: AppConfig){
    }

    addProduct(product: ProductModel){

        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });


        return this.http.post(this.config.apiUrl + "/api/XpayCommand/addoreditproduct", {itemName: product.name, description:product.description, amount: product.amount,
        link: product.link, costCode: product.costCode, imageUrl: product.imageUrl, isActive: product.isActive, userid: localStorage.getItem('currentUser'), 
        productCategoryId: product.productCategory}, options)
        .map((response: Response) => response.json())
        //.catch((error:any) => Observable.throw(error.json().error || 'Server error'));
      }

    updateProduct(product: ProductModel){
        return this.http.post(this.config.apiUrl, {})
        .map((response: Response) => {
            //Login successful if there is a JWT token in the response
            
        })
    }

    getProducts(){
        return this.http.get(this.config.apiUrl + '/api/XpayQuery/getproducts')
        .map((response: Response) => response.json())
        .catch((error:any) => Observable.throw(error.json().error || 'Server error'));
    }

    getProductsById(id: number){
        return this.http.post(this.config.apiUrl, {})
        .map((response: Response) => {
            //Login successful if there is a JWT token in the response
            
        })
    }

}