export class AppConfig{
    public readonly apiUrl = 'http://localhost:4000'
}