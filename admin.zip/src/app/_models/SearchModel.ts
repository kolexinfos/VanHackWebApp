export class SearchModel {

  constructor(public searchtext: string, public category:string, public amount: number, public email: string, 
  public externalTransactionId: string, public fullname: string, public LoggedDate: string, public productId : string, public status : string, 
  public transactionDate: string, public transactionID : string) {
      
  }
}