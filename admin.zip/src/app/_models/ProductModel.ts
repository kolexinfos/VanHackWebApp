export class ProductModel {
  // public name: string;
  // public description: string;
  // public amount : number;
  // public link: string;
  // public code: string;
  // public imageUrl: string;
  // public isActive: boolean;
  // public productCategory: string


  constructor(public name: string, public description: string,public amount: number, public link: string, 
                    public costCode:string, public imageUrl: string, public isActive: boolean, public productCategory: string) {
      // this.name = name;


  }
}