export class LoginModel {
  public email: string;
  public password: string;

  constructor(email: string, password: string) {

  }
}