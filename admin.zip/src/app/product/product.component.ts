import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

 private products : Array<ProductModel> = new Array<ProductModel>();

//   public products = [
//     {id: 1, name:'Superman'},
//     {id: 2, name:'Batman'},
//     {id: 5, name:'BatGirl'},
//     {id: 3, name:'Robin'},
//     {id: 4, name:'Flash'}
// ];

  constructor(router:Router) { 

    this.products.push(new ProductModel(1,"kolade","kolade","kolade","developing"))

    console.log(this.products);

  }

  ngOnInit() {

  }

  addProduct(){
    console.log("Add product Clicked");
  }

  refreshProduct(){
     console.log("Refresh product Clicked");
  }

  rowClicked(product){
    console.log("row clicked " + product.name + " " + product.id)
   // this.router.navigate(['/details']);
    //[routerLink]="['details', product.id]
  }

}

export class ProductModel {
  public id: number;
  public name: string;
  public description: string;
  public costCode: string;
  public status: string;

  constructor(id:number, name: string, description:string, costCode: string, status:string) {
      this.name = name;
      this.description = description;
      this.costCode = costCode;
      this.status = status;
      this.id = id;
  }
}
