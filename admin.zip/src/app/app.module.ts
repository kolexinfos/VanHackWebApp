import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { MaterialModule } from '@angular/material';
import { FormsModule }   from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { ResetComponent } from './reset/reset.component';
import { LoginComponent } from './login/login.component';
import { MainComponent } from './main/main.component';
import { ProductComponent } from './product/product.component';
import { CreateComponent } from './create/create.component';
import { SearchComponent } from './search/search.component';
import { RolesComponent } from './roles/roles.component';
import { DetailsComponent } from './details/details.component';
import { AlertService, AuthenticationService, UserService } from './_services/index';

import { AuthGuard } from './_guards/index';
import { AppConfig } from './app.config';

const appRoutes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'reset', component: ResetComponent },
  { path: 'main', component: MainComponent,
    children : [
      {path:'', redirectTo: 'product', pathMatch:'full'},
      {path:'product', component: ProductComponent},
      {path:'create', component: CreateComponent},
      {path:'search', component: SearchComponent},
      {path:'roles', component: RolesComponent},
      {path:'details/:id', component: DetailsComponent},
    ],
    canActivate: [AuthGuard]
  },
];


@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    ResetComponent,
    LoginComponent,
    MainComponent,
    ProductComponent,
    CreateComponent,
    SearchComponent,
    RolesComponent,
    DetailsComponent
  ],
  imports: [
    BrowserModule,
    MaterialModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(
      appRoutes,
      {enableTracing: true }
    )
  ],
  providers: [
    AuthGuard,
    AuthenticationService,
    AlertService,
    AppConfig
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
