import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { LoginModel} from '../_models/LoginModel'
import { AlertService, AuthenticationService } from '../_services/index';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private alertService: AlertService) { }

  title = 'X-Pay Admin Portal';
  active: boolean = true;
  model: any = {};
  loading = false;
  returnUrl: string;


  login: LoginModel = new LoginModel("kolexinfos@gmail.com", "");

  doLogin() {
      console.log(this.login);
      this.login = new LoginModel("","");
      this.active = false;
      setTimeout( () => this.active = true, 0);

      this.loading = true;
        this.authenticationService.login(this.model.username, this.model.password)
            .subscribe(
                data => {
                    this.router.navigate([this.returnUrl]);
                },
                error => {
                    this.alertService.error('Username or password is incorrect');
                    this.loading = false;
                });
  }

  ngOnInit() {
     // reset login status
        this.authenticationService.logout();

        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }


}
