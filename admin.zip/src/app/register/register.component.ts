import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  active : boolean = true;
  register : RegisterModel = new RegisterModel("","","","","");


  constructor() { }

  ngOnInit() {
  }

}

export class RegisterModel {
  public fullname : string;
  public email: string;
  public password: string;
  public phone: string;
  public username: string

  constructor(fullname:string, phone: string, email: string, password: string, username : string) {
    this.fullname = fullname;
    this.phone = phone;
    this.email = email;
    this.password = password;
    this.username = username;
  }
}
