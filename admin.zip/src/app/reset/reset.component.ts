import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reset',
  templateUrl: './reset.component.html',
  styleUrls: ['./reset.component.css']
})
export class ResetComponent implements OnInit {

  active:boolean = true;
  reset : ResetModel = new ResetModel("");


  constructor() { }

  ngOnInit() {
  }

}

export class ResetModel {
  public email: string;

  constructor(email: string) {

  }
}